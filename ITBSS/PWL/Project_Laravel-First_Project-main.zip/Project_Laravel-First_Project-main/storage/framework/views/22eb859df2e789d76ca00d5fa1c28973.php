<!DOCTYPE html>
<html>
<head>
    <title>KRS Mahasiswa</title>
</head>
<body>
    <h2>KRS <?php echo e($mahasiswa->name); ?></h2>
    <p>Total SKS: <?php echo e($mahasiswa->totalSks()); ?> / <?php echo e($mahasiswa->maksimal_sks); ?></p>

    
    <?php if(session('success')): ?>
        <div style="color: green"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div style="color: red"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <hr>

    <h3>Tambah Mata Kuliah</h3>
    <form action="<?php echo e(route('krs.store', $mahasiswa->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <select name="matakuliah_id" required>
            <option value="">-- Pilih Mata Kuliah --</option>
            <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($mk->id); ?>">
                    <?php echo e($mk->namamk); ?> (<?php echo e($mk->sks); ?> SKS)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit">Tambah</button>
    </form>

    <hr>

    <h3>Mata Kuliah yang Diambil</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>Nama Mata Kuliah</th>
            <th>SKS</th>
            <th>Aksi <?php echo e($mahasiswa->matakuliah->count()); ?></th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $mahasiswa->matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($mk->namamk); ?></td>
                <td><?php echo e($mk->sks); ?></td>
                <td>
                    <form action="<?php echo e(route('krs.destroy', [$mahasiswa->id, $mk->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3">Belum ada mata kuliah yang diambil</td>
            </tr>
        <?php endif; ?>
    </table>
</body>
</html>
<?php /**PATH C:\Users\RonneyP\ITBSS\PWL\Project_Laravel-First_Project-main\resources\views/IndexKRS.blade.php ENDPATH**/ ?>
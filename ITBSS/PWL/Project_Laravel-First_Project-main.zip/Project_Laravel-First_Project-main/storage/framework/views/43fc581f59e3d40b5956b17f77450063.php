<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Mata Kuliah</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body class="bg-light">
  <div class="container mt-5">
    <div class="card shadow-lg">
      <div class="card-header bg-primary text-white">
        <h2 class="mb-0">Create MataKuliah</h2>
      </div>
      <div class="card-body">
        <?php
        $isEdit = isset($matakuliah);
        ?>

        <form action="<?php echo e($isEdit ? route('matakuliah.update', $matakuliah->id) : route('matakuliah.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php if($isEdit): ?> 
            <?php echo method_field('PUT'); ?>
          <?php endif; ?>

          <div class="mb-3">
            <label for="kodemk" class="form-label">Kode MK</label>
            <input type="text" name="kodemk" id="kodemk" class="form-control" placeholder="Masukkan Kode MK"
                    value="<?php echo e(old('kodemk', $isEdit ? $matakuliah->kodemk : '')); ?>">
          </div>

          <div class="mb-3">
            <label for="namamk" class="form-label">Nama MK</label>
            <input type="text" name="namamk" id="namamk" class="form-control" placeholder="Masukkan Nama MK lengkap"
                    value="<?php echo e(old('namamk', $isEdit ? $matakuliah->namamk : '')); ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Jurusan</label>
            <?php $__currentLoopData = ['Bisnis Digital','Kewirausahaan','Sistem dan Teknologi Informasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check">
                <input type="radio" name="jurusan" value="<?php echo e($jurusan); ?>" class="form-check-input"
                    <?php echo e(($isEdit && $matakuliah->jurusan == $jurusan) ? 'checked' : ''); ?>>
                <label class="form-check-label"><?php echo e($jurusan); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

           <div class="mb-3">
            <label for="sks" class="form-label">SKS</label>
            <input type="text" name="sks" id="sks" class="form-control" placeholder="Masukkan Jumlah SKS"
                    value="<?php echo e(old('sks', $isEdit ? $matakuliah->sks : '')); ?>">
          </div>

           <div class="mb-3">
            <label for="dosen_id" class="form-label">Dosen</label>
            <select name="dosen_id" id="dosen_id" class="form-control" placeholder="Masukkan Nama Dosen">
              <?php $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($dosen->id); ?>"><?php echo e($dosen->Nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <button type="submit" class="btn btn-primary">
                <?php echo e($isEdit ? 'Update' : 'Create'); ?>

          </button>
          <a href="<?php echo e(url('/matakuliah')); ?>" class="btn btn-secondary">Batal</a>
        </form>
      </div>
    </div>
  </div>

</body>
</html><?php /**PATH C:\Users\RonneyP\ITBSS\PWL\Project_Laravel-First_Project-main\resources\views/CreateMataKuliah.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mahasiswa</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body class="bg-light">

  <div class="container py-5">
    <!-- Judul dan tombol -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-bold text-primary">Daftar Mahasiswa</h2>
      <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-success">
        <i class="bi bi-plus-lg"></i> Create Mahasiswa
      </a>
    </div>

    <!-- Kartu Tabel -->
    <div class="card shadow">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>No</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Tempat Lahir</th>
                <th>Tanggal Lahir</th>
                <th>Jurusan</th>
                <th>Angkatan</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($mahasiswa['id']); ?></td>
                <td><?php echo e($mahasiswa['NIM']); ?></td>
                <td><?php echo e($mahasiswa['name']); ?></td>
                <td><?php echo e($mahasiswa['tempat_lahir']); ?></td>
                <td><?php echo e($mahasiswa['tanggal_lahir']); ?></td>
                <td><?php echo e($mahasiswa['jurusan']); ?></td>
                <td><?php echo e($mahasiswa['angkatan']); ?></td>
                <td>
                  <div class="btn-group" role="group">
                    <a href="<?php echo e(route('mahasiswa.edit', $mahasiswa->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('mahasiswa.destroy', $mahasiswa->id)); ?>" method="POST" onsubmit="return confirm('Yakin mau hapus?')">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="8" class="text-center text-muted">Belum ada data mahasiswa.</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>

</body>
</html>
<?php /**PATH C:\Users\Ronney Pangnathan\ITBSS\PWL\Project_Laravel-First_Project-main\resources\views/IndexMahasiswa.blade.php ENDPATH**/ ?>
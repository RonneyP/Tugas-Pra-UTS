<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MataKuliah</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body class="bg-light">

  <div class="container py-5">
    <!-- Judul dan tombol -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-bold text-primary">Daftar Mata Kuliah</h2>
      <a href="<?php echo e(route('matakuliah.create')); ?>" class="btn btn-success">
        <i class="bi bi-plus-lg"></i> Create Mata Kuliah
      </a>
    </div>

    <!-- Kartu Tabel -->
    <div class="card shadow">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>No</th>
                <th>Kode MK</th>
                <th>Nama MK</th>
                <th>Jurusan</th>
                <th>SKS</th>
                <th>dosen id</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($matakuliah['id']); ?></td>
                <td><?php echo e($matakuliah['kodemk']); ?></td>
                <td><?php echo e($matakuliah['namamk']); ?></td>
                <td><?php echo e($matakuliah['jurusan']); ?></td>
                <td><?php echo e($matakuliah['sks']); ?></td>
                <td><?php echo e($matakuliah->dosen->Nama); ?></td>
                <td>
                  <div class="btn-group" role="group">
                    <a href="<?php echo e(route('matakuliah.edit', $matakuliah->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('matakuliah.destroy', $matakuliah->id)); ?>" method="POST" onsubmit="return confirm('Yakin mau hapus?')">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="8" class="text-center text-muted">Belum ada data mahasiswa.</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>

</body>
</html><?php /**PATH C:\Users\RonneyP\ITBSS\PWL\Project_Laravel-First_Project-main\resources\views/IndexMataKuliah.blade.php ENDPATH**/ ?>
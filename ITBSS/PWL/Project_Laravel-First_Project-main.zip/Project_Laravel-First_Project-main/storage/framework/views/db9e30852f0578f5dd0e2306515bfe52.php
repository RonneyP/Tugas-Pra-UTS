<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dosen</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body class="bg-light">

  <div class="container py-5">
    <!-- Judul dan tombol -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-bold text-primary">Daftar Dosen</h2>
        <a href="<?php echo e(route('dosen.create')); ?>" class="btn btn-success">
        <i class="bi bi-plus-lg"></i> Create Dosen
      </a>
    </div>
    

    <!-- Kartu Tabel -->
    <div class="card shadow">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>No</th>
                <th>NIP</th>
                <th>Nama</th>
                <th>Pendidikan Terakhir</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($dosen['id']); ?></td>
                <td><?php echo e($dosen['NIP']); ?></td>
                <td><?php echo e($dosen['Nama']); ?></td>
                <td><?php echo e($dosen['Pendidikan_Terakhir']); ?></td>
                <td>
                    <div class="btn-group" role="group">
                    <a href="<?php echo e(route('dosen.edit', $dosen->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('dosen.destroy', $dosen->id)); ?>" method="POST" onsubmit="return confirm('Yakin mau hapus?')">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                    </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="8" class="text-center text-muted">Belum ada data dosen.</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>

</body>
</html>
<?php /**PATH C:\Users\RonneyP\ITBSS\PWL\Project_Laravel-First_Project-main\resources\views/IndexDosen.blade.php ENDPATH**/ ?>